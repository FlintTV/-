package me.flintofficial;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class RestartManager {

    private final autorestart plugin;
    private long totalTime;
    private List<Integer> warningTimes;
    private Map<Integer, String> messages;
    private BukkitRunnable task;

    public RestartManager(autorestart plugin) {
        this.plugin = plugin;
        loadConfigValues();
    }

    public void loadConfigValues() {
        totalTime = plugin.getConfig().getLong("total-time", 21600);
        warningTimes = new ArrayList<>(plugin.getConfig().getIntegerList("warnings"));
        Collections.sort(warningTimes, Collections.reverseOrder());

        messages = new HashMap<>();
        for (int time : warningTimes) {
            String msg = plugin.getConfig().getString("messages." + time,
                    "<red>⚠ The server will restart in " + time + " seconds!");
            messages.put(time, msg);
        }
    }

    public void startTask() {
        if (task != null) task.cancel();

        task = new BukkitRunnable() {
            private long secondsPassed = 0;

            @Override
            public void run() {
                secondsPassed++;
                long timeLeft = totalTime - secondsPassed;

                if (messages.containsKey((int) timeLeft)) {
                    String rawMsg = messages.get((int) timeLeft)
                            .replace("{time}", formatTime((int) timeLeft));
                    broadcast(rawMsg);
                }

                if (secondsPassed >= totalTime) {
                    broadcast("<red><bold>Restarting server...");
                    Bukkit.spigot().restart();
                    cancel();
                }
            }
        };
        task.runTaskTimer(plugin, 20L, 20L);
    }

    private String formatTime(int seconds) {
        int minutes = seconds / 60;
        return (minutes > 0) ? minutes + " minutes" : seconds + " seconds";
    }

    private void broadcast(String miniMessageText) {
        Component component = MiniMessage.miniMessage().deserialize(miniMessageText);
        Bukkit.getServer().sendMessage(component);
    }
}
