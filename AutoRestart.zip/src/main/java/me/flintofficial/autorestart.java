package me.flintofficial;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class autorestart extends JavaPlugin {

    private RestartManager restartManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();


        restartManager = new RestartManager(this);
        restartManager.startTask();


        getCommand("autorestart").setExecutor(new RestartCommand(this));

        Bukkit.getConsoleSender().sendMessage("§d§l     _         _        ____           _             _   ");
        Bukkit.getConsoleSender().sendMessage("§d§l    / \\  _   _| |_ ___ |  _ \\ ___  ___| |_ __ _ _ __| |_ ");
        Bukkit.getConsoleSender().sendMessage("§d§l   / _ \\| | | | __/ _ \\| |_) / _ \\/ __| __/ _` | '__| __|");
        Bukkit.getConsoleSender().sendMessage("§d§l  / ___ \\ |_| | || (_) |  _ <  __/\\__ \\ || (_| | |  | |_ ");
        Bukkit.getConsoleSender().sendMessage("§d§l /_/   \\_\\__,_|\\__\\___/|_| \\_\\___||___/\\__\\__,_|_|   \\__|");
        Bukkit.getConsoleSender().sendMessage("§7§lAuthor: §e@FlintTV");
        Bukkit.getConsoleSender().sendMessage("§7§lVersion: §e1.0.0");
        Bukkit.getConsoleSender().sendMessage("§7§lMore At: §a§nhttps://www.spigotmc.org/resources/authors/saro_gamer.1252225/");
        Bukkit.getConsoleSender().sendMessage("§b§lAutoRestart: §a§lPLUGIN ENABLED");
    }

    @Override
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage("§c§l     _         _        ____           _             _   ");
        Bukkit.getConsoleSender().sendMessage("§c§l    / \\  _   _| |_ ___ |  _ \\ ___  ___| |_ __ _ _ __| |_ ");
        Bukkit.getConsoleSender().sendMessage("§c§l   / _ \\| | | | __/ _ \\| |_) / _ \\/ __| __/ _` | '__| __|");
        Bukkit.getConsoleSender().sendMessage("§c§l  / ___ \\ |_| | || (_) |  _ <  __/\\__ \\ || (_| | |  | |_ ");
        Bukkit.getConsoleSender().sendMessage("§c§l /_/   \\_\\__,_|\\__\\___/|_| \\_\\___||___/\\__\\__,_|_|   \\__|");
        Bukkit.getConsoleSender().sendMessage("§7§lAuthor: §e@FlintTV");
        Bukkit.getConsoleSender().sendMessage("§7§lVersion: §e1.0.0");
        Bukkit.getConsoleSender().sendMessage("§7§lMore At: §a§nhttps://www.spigotmc.org/resources/authors/saro_gamer.1252225/");
        Bukkit.getConsoleSender().sendMessage("§b§lAutoRestart: §c§lPLUGIN DISABLED");
    }

    public RestartManager getRestartManager() {
        return restartManager;
    }
}
